﻿using System;

namespace jabaricarpets
{
    class Program
    {
        private const double pricePerSquareFoot = 8.99;
        private const double labourCostPerSquareFoot = 0.35;
        private const double discountPerFoot = 9;
        private const double taxRate = 8.25;
        static void Main(string[] args)
        {
            Console.WriteLine("\t\t*******************************\n");
            Console.WriteLine("\t\t****** UKMC CARPET STORE ******\n");
            Console.WriteLine("\t\t*******************************\n");
            
            Console.Write($"\n\t\tCustomer Name: ");
            var name = Console.ReadLine();
            Console.WriteLine("\n\t\t**** MEASUREMENTS ***\n");

            
            Console.Write("\t\tLength in feet: ");
            var length = Convert.ToDouble(Console.ReadLine());

            Console.Write("\n\t\tWidth in feet: ");
            var width = Convert.ToDouble(Console.ReadLine());

            var area = width*length;
            Console.WriteLine($"\n\t\tArea of the room in sq feet: {area}");

            var carpetMeasurements = new Carpet(width, length);
            var cost = carpetMeasurements.CalculatePrice(pricePerSquareFoot);
            var labourCost = carpetMeasurements.LaborCost(labourCostPerSquareFoot);
            var totalDiscount = discountPerFoot/100 * cost;
            var subTotal = cost + labourCost - totalDiscount;
            var tax = taxRate/100 * subTotal;
            var total = subTotal + tax;

            Console.WriteLine("\n\t\t\t\tCHARGES");
            Console.WriteLine("\tDESCRIPTION \t\t COST/SQ.FT \t\tCHARGE/ROOM");

            Console.WriteLine($"\tCarpet \t\t\t {pricePerSquareFoot} \t\t\t {cost}");
            Console.WriteLine($"\tLabour \t\t\t {labourCostPerSquareFoot} \t\t\t {labourCost}");

            Console.WriteLine($"\n\tINSTALLED PRICE \t\t\t\t {cost}");
            Console.WriteLine($"\tDiscount \t\t {discountPerFoot}% \t\t\t {totalDiscount}");

            Console.WriteLine($"\n\n\tSUBTOTAL \t\t {subTotal}");
            Console.WriteLine($"\tTax \t\t\t {taxRate}%");

            Console.WriteLine($"\n\tTOTAL \t\t\t {total}");

            Console.WriteLine("\nPress any Button to Terminate the Program.....");
            Console.ReadKey();
        }
    }

    public class Customer
    {
        public Customer(string customerName)
        {
            this.CustomerName = customerName;

        }

        public string CustomerName { get; set; }
    }

    public class Carpet 
    {
        public Carpet(double width, double height)
        {
            this.Width = width;
            this.Height = height;
        }

        public double Width { get; set; }

        public double Height { get; set; }

        public double Price { get; set; }

        public double CalculatePrice(double pricePerFoot) {
            var area = Width * Height;
            Price = area * pricePerFoot;
            return Price;
        }

        public double LaborCost(double laborcost) {
            return Width * Height * laborcost;
        }
    }
}
